import 'package:flutter/material.dart';

class Car {
  int primaryNumber = 0;
  String barand = "";
  String model = "";
  Color bodyColor = Colors.white;

  Widget item() {
    return Container(color: bodyColor,child: Row(children: [
      Text("barand: " + barand,style: TextStyle(fontSize: 18),),
      SizedBox(width: 20,),
      Text("Model: $model",style: TextStyle(fontSize: 18))

    ],),);
  }
}
