import 'package:flutter/material.dart';

import 'Car.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<Car> listCars = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Car car1= Car();
    car1.primaryNumber=1291;
    car1.barand="Ferrari";
    car1.model="F50";
    car1.bodyColor=Colors.red;
    listCars.add(car1);

    Car car2= Car();
    car2.primaryNumber=1291;
    car2.barand="Peikan";
    car2.model="p50";
    car2.bodyColor=Colors.blue;
    listCars.add(car2);

  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Container(
        child: ListView.builder(
          itemCount: listCars.length,
          itemBuilder: (context, index) {
            return Container(padding: EdgeInsets.all(10),
              child: InkWell(onTap: () {
              print(index);
            },child: listCars[index].item()),);
          },
        )),
    );
  }
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    print("dispose");

  }
}
