import 'package:flutter/material.dart';

import 'Car.dart';

class CarPage extends StatelessWidget {
  Car car;
  CarPage({super.key,required this.car});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: Text(car!.barand)),
      body:  Center(
        child: Text(
          "number: ${car!.primaryNumber}",
          style: TextStyle(fontSize: 24.0),
        ),
      ),
    );
  }
}