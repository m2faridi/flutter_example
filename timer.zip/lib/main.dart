import 'dart:async';

import 'package:flutter/material.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  Timer? timer;
  int seconds=0;
  int mineite=0;
  int h=0;
  void startTimer(){
    timer = Timer.periodic(const Duration(milliseconds: 1000), (timer) {
      seconds+=1;
      if(seconds == 60){
        seconds=0;
        mineite+=1;
      }
      if(mineite==60) {
        mineite = 0;
        h += 1;
      }

      setState(() {});
    });
  }
  @override
  void initState() {
    super.initState();
    startTimer();


  }
  @override
  Widget build(BuildContext context) {


    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(child: Container(child: Column(mainAxisSize: MainAxisSize.min,children: [Text("$h:$mineite:$seconds"),
      TextButton(onPressed: () {
        if(timer!.isActive){
          timer!.cancel();
        }else{
          startTimer();
        }

      }, child: Text(timer!.isActive?"Stop":"Start"))],),),),
    );
  }
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();

  }
}
